/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videojuegomatriz;

import Matriz.CrearMapas;
import Matriz.Jugador;
import Matriz.Mapa;
import java.io.*;
import java.util.Scanner;

/**
 *
 * @author victo
 */
public class VideoJuegoMatriz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        
        Mapa mapa=new Mapa(22,7);
            File f=new File("C:\\Users\\victo\\Desktop\\Nuevo documento de texto.txt");
            CrearMapas crator=new CrearMapas(f);
            crator.genString();
            //System.out.println(crator);
        mapa.CrearMapa(crator.toString(), 22, 7);
//        try{
//            System.out.println(mapa);
//        }catch(Exception e){
//            System.out.println(e);
//        }
        mapa.genMonedas(3);
//        try{
//            System.out.println(mapa);
//        }catch(Exception e){
//            System.out.println(e);
//        }
        
        Jugador v=new Jugador(1, 1, mapa);
        
        String input="nada";
        Scanner teclado;
        while(input.charAt(0)!='e'){
            System.out.println(mapa);
            System.out.println("Introduce una direccion (l,r,u,d, e-->salir):  ");
            teclado = new Scanner(System.in);
            input=teclado.nextLine();
            v.nextStep(input, v);
        }
    }
}

