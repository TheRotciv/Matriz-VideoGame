/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matriz;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author victo
 */
public class Jugador  extends Entidad{
    private int monedas;
           
    public Jugador(int x, int y, Mapa mapa) {
        super(x, y, mapa);
        super.setNombre("Victor");
        super.getMapa().modMapa(x, y, this);
        monedas = 0;
        
    }
    
    public void cambiarMonedas(int a){
        monedas = monedas + a;
        System.out.println("Tienes "+a+" moneda(s)");
    }

    public String toString() {
        return " "+super.getNombre().charAt(0)+" "; //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
}
