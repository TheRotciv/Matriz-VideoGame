/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matriz;

/**
 *
 * @author victo
 */
public class Moneda extends Entidad {
    
    
    
    public Moneda(int x, int y, Mapa mapa) {
        super(x, y, mapa);
        super.setNombre("Moneda");
    }

    @Override
    public String toString() {
        return " C "; //To change body of generated methods, choose Tools | Templates.
    }
    
}
