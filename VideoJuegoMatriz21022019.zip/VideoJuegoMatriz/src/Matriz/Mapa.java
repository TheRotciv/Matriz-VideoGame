/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matriz;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author victo
 */
public class Mapa {
    private Entidad[][] mapa;
    private int x;
    private int y;
    private ArrayList<int[]> camino;
    private ArrayList<int[]> monedas;
    
    public Mapa(int x, int y){
        mapa=new Entidad[x][y];
        camino=new ArrayList();
        monedas=new ArrayList();
        this.x=x;
        this.y=y;
}
    
    public void CrearMapa(String mapeado, int x, int y){
        char aux1;
        int aux2;
        
        
        if(x==this.x || y==this.y || mapeado.length()==(this.x*this.y)){
            
            for(int i=y-1;i>=0;i--){
                for (int j = 0; j < x; j++) {
                    aux2=(i*x)+j;
                    aux1=mapeado.charAt(aux2);
                    if (aux1=='0'){
                        mapa[j][i]=new Terreno(j, i, this, "   ");
                        int[] coord={j,i};
                        camino.add(coord);
                    }else mapa[j][i]=new Terreno(j, i, this, "|/|");
                    
                }
            }
            
        }else System.out.println("Tamaño de mapa incompleto");
    }

    @Override
    public String toString() {
        String impresion="";
        for(int i=y-1;i>=0;i--){
            for (int j = 0; j < this.x; j++) {
                impresion=impresion+mapa[j][i].toString();   
            }
            impresion=impresion+"\n";
        }  
        return impresion; //To change body of generated methods, choose Tools | Templates.
    }
    
    public void genMonedas(int a){
        int t;
        int[] r;
        int x;
        int y;
        ArrayList<int[]> aux=camino;
        for (int i = 0; i < a; i++) {
            t=(new Random()).nextInt(aux.size());
            r=aux.remove(t);
            monedas.add(r);
            x=r[0];
            y=r[1];
            mapa[x][y]=new Moneda(x, y, this);
                     
        }
    }

    public ArrayList<int[]> getCamino() {
        return camino;
    }
    
    
    public void modMapa(int x, int y,Entidad ent){
        
        mapa[x][y]= ent;
    }
    
    public void modMapa(int x, int y, int x2,int y2, Entidad ent){
        String aux=mapa[x][y].getNombre();
        
       if(aux!="|/|"){
            ent.setX(x);
            ent.setY(y);
            mapa[x][y]=ent;
            mapa[x2][y2]=new Terreno(x2, y2, this, "   "); 
//            switch (aux){
//            case "   ":break;
//            case " C ":
//                System.out.println("¡¡Has encontrado una moneda!!");
//            
//            default:System.out.println("Te has estampado contra nuna pared");
            
//        }
       }else System.out.println("Te has estampado contra una pared");
    }
    public Entidad[][] getMapa() {
        return mapa;
    }

    
    
}
