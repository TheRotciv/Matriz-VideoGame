/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matriz;

/**
 *
 * @author victo
 */
public class Terreno extends Entidad {
    
    public Terreno(int x, int y, Mapa mapa, String nombre) {
        super(x, y, nombre, mapa);
    }

    @Override
    public String toString() {
        return super.getNombre();
    }
    
}
