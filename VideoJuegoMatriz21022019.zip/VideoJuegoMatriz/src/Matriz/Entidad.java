/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matriz;

/**
 *
 * @author victo
 */
public abstract class Entidad {
    private int x;
    private int y;
    private String nombre;
    private Mapa mapa;

    public Entidad(int x, int y, Mapa mapa) {
        this.x = x;
        this.y = y;
        this.mapa=mapa;
    }

    public Entidad(int x, int y, String nombre, Mapa mapa) {
        this.x = x;
        this.y = y;
        this.nombre = nombre;
        this.mapa = mapa;
    }
    
    
    //GETTERS
    //---------------------------------------------------------------------
    
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String getNombre() {
        return nombre;
    }

    public Mapa getMapa() {
        return mapa;
    }
    
    
    
    //-----------------------------------------------------------------------
    //SETTERS
    //-----------------------------------------------------------------------
    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    //------------------------------------------------------------------------
    //------------------------------------------------------------------------
    
    public void nextStep(String a, Entidad ent){
        
        switch(a){
            
            case "l": mapa.modMapa((this.x)-1, this.y, this.x, this.y, ent);
            break;
            case "r":mapa.modMapa((this.x)+1, this.y, this.x, this.y, ent);  
            break;
            case "u":mapa.modMapa((this.x), this.y+1, this.x, this.y, ent);    
            break;
            case "d":mapa.modMapa((this.x), this.y-1, this.x, this.y, ent);    
            break;
            case "e":System.out.println("Terminando juego...");
            break;
            default:System.out.println("Esa no es una direccion valida");
        }
    }
            
}

    
    
    
    
    
    
    
    

