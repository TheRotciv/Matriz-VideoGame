/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videojuegomatriz;

import Matriz.Mapa;

/**
 *
 * @author victo
 */
public class VideoJuegoMatriz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Mapa mapa=new Mapa(20,5);
        mapa.CrearMapa("11111111111111111111"+"10000000000000000001"+"11111111111111111101"+"10000000000000000001"+"11111111111111111111", 20, 5);
        try{
            System.out.println(mapa);
        }catch(Exception e){
            System.out.println(e);
        }
        mapa.genMonedas(3);
        try{
            System.out.println(mapa);
        }catch(Exception e){
            System.out.println(e);
        }
        
    }
    
}
