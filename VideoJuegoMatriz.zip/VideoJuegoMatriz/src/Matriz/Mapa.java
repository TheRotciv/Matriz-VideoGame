/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Matriz;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author victo
 */
public class Mapa {
    private Entidad[][] mapa;
    private int x;
    private int y;
    private ArrayList<int[]> camino;
    private ArrayList<int[]> monedas;
    
    public Mapa(int x, int y){
        mapa=new Entidad[x][y];
        camino=new ArrayList();
        monedas=new ArrayList();
        this.x=x;
        this.y=y;
}
    
    public void CrearMapa(String mapeado, int x, int y){
        char aux1;
        int aux2;
        
        
        if(x==this.x || y==this.y || mapeado.length()==(this.x*this.y)){
            
            for(int i=0;i<y;i++){
                for (int j = 0; j < x; j++) {
                    aux2=(i*x)+j;
                    aux1=mapeado.charAt(aux2);
                    if (aux1=='0'){
                        mapa[j][i]=new Terreno(j, i, this, "   ");
                        int[] coord={j,i};
                        camino.add(coord);
                    }else mapa[j][i]=new Terreno(j, i, this, "|/|");
                    
                }
            }
            
        }else System.out.println("Tamaño de mapa incompleto");
    }

    @Override
    public String toString() {
        String impresion="";
        for(int i=0;i<this.y;i++){
            for (int j = 0; j < this.x; j++) {
                impresion=impresion+mapa[j][i].toString();   
            }
            impresion=impresion+"\n";
        }  
        return impresion; //To change body of generated methods, choose Tools | Templates.
    }
    
    public void genMonedas(int a){
        int t;
        int[] r;
        int x;
        int y;
        ArrayList<int[]> aux=camino;
        for (int i = 0; i < a; i++) {
            t=(new Random()).nextInt(aux.size());
            r=aux.remove(t);
            monedas.add(r);
            x=r[0];
            y=r[1];
            System.out.println(r[0]+" x "+ r[1]+" y");
            mapa[x][y]=new Moneda(x, y, this);
                     
        }
    }
    
}
